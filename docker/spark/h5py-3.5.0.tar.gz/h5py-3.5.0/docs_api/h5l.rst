Module H5L
==========

Linkproxy objects
-----------------

.. automodule:: h5py.h5l
    :members:

Module constants
----------------

Link types
~~~~~~~~~~

.. data:: TYPE_HARD
.. data:: TYPE_SOFT
.. data:: TYPE_EXTERNAL
