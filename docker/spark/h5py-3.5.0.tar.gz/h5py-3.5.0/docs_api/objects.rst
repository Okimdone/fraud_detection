Base object classes
===================

.. automodule:: h5py._objects

.. autoclass:: ObjectID
