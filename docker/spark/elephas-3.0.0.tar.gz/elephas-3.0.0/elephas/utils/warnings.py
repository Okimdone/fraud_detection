class ElephasWarning(Warning):
    """Custom warning class for any Elephas issues"""
